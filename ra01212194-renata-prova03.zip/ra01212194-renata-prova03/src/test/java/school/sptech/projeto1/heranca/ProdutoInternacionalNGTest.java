
//package school.sptech.projeto1.heranca;
//
//import static org.testng.Assert.*;
//
//
//public class ProdutoInternacionalNGTest {
//    
//    public ProdutoInternacionalNGTest() {
//    }
//
//    @org.testng.annotations.BeforeClass
//    public static void setUpClass() throws Exception {
//    }
//
//    @org.testng.annotations.AfterClass
//    public static void tearDownClass() throws Exception {
//    }
//
//    @org.testng.annotations.BeforeMethod
//    public void setUpMethod() throws Exception {
//    }
//
//    @org.testng.annotations.AfterMethod
//    public void tearDownMethod() throws Exception {
//    }
//
//    @org.testng.annotations.Test
//    public void testSomeMethod() {
//        // TODO review the generated test code and remove the default call to fail.
//        fail("The test case is a prototype.");
//    }
//    
//}
