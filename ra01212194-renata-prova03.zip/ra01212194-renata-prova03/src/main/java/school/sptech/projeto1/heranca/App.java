
package school.sptech.projeto1.heranca;


public class App {
    public static void main(String[] args) {
        //Estânciar classes 
        Carrinho car1 = new Carrinho ("aGMax", 0);
    }
    
}
